<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Vimeo\Laravel\VimeoManager;
//use Vimeo\Laravel\Facades\Vimeo;

class laravelController extends Controller
{
    public function storewithform(Request $request, VimeoManager $vimeo)
    {
        $uri = $vimeo->upload($request->video,[
            'name' => 'first',
            'description' => 'first des'
        ]);
        return $uri;
    }
}
