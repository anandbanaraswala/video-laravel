<?php

declare(strict_types=1);

return [
    'default' => 'main',
    'connections' => [

        'main' => [
            'client_id' => env('VIMEO_CLIENT', '790e6b28cdc1a9dc349b3bbf7661823e1b314497'),
            'client_secret' => env('VIMEO_SECRET', 'VFBbqvrsP4+xKdqCf2Q8zh9yvk4mZ3vFhLs+6+Cd/mROnT8BOkwX9qZXH07fhvOAeQruu+mYGbUgMlubDKbZPe4pjyr8kaECofTCpyULgN9+cKIxbR6ZXwUxp55veE3z'),
            'access_token' => env('VIMEO_ACCESS', '3a44126f5740357ed32db3fb928ee9ca'),
        ],

        'alternative' => [
            'client_id' => env('VIMEO_ALT_CLIENT', 'your-alt-client-id'),
            'client_secret' => env('VIMEO_ALT_SECRET', 'your-alt-client-secret'),
            'access_token' => env('VIMEO_ALT_ACCESS', null),
        ],

    ],

];

?>
