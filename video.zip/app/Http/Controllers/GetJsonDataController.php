<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\getjsondatamodel;

class GetJsonDataController extends Controller
{
    function result()
    {
        $fetch_data = getjsondatamodel::all();
        return response(array("message"=>$fetch_data),200)->header("Content-Type","application/json");
    }
}
