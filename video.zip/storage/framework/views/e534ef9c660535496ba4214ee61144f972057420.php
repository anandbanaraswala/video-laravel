<?php $__env->startSection("mywebpage"); ?>
    <div class="container mt-5">
        <h1 class="mt-3">Upload Video</h1>
        <!-- store with form -->
        <!-- <form enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <input type="file" name="video" accept="video/*" required id="file">
            <input type="submit" id="submit">
        </form> -->
         <!-- end store with form -->

        <!-- store with form with ajax -->
        <form enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="video" accept="video/*" required id="file">
            <input type="submit" id="submit">
        </form>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $("form").submit(function(e){
                //e.preventDefault();
                alert();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\it_company\video\resources\views/laravel.blade.php ENDPATH**/ ?>