<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Vimeo\Laravel\VimeoManager;
use Vimeo\Laravel\Facades\Vimeo;

class laravelVimeoAjax extends Controller
{
    public function storewithajax(Request $request, VimeoManager $vimeo)
    {
        /*$videofile = $request->file('file');
        $filename = time().'_'.$videofile->getClientOriginalName();
        $location = $videofile->getPathName(); // this is my file
        $uri = $vimeo->upload($videofile,[
            'name' => $filename,
        ]);
        return response()->json(['message' => "done file name is : ".$filename], 200);*/
        $videofile = $request->file('file');
        $filename = time().'_'.$videofile->getClientOriginalName();
        $location = $videofile->getPathName(); // this is my file
        $filesize = filesize($location);
        $open_file = fopen($location,"rb"); // 'rb' means read in binary.
        $newfile = fopen($filename,"w");
        $start_from = 0;
        while($start_from < $filesize)
        {
            $binary = fread($open_file,10000);
            fwrite($newfile,$binary);
            $start_from += strlen($binary);
            fseek($open_file,$start_from);
        }
        $videofile->move(public_path('files'), $filename);
        return response()->json(['message' => "done"], 200);
        fclose($open_file);
        fclose($newfile);
        unlink($location);
    }
}
