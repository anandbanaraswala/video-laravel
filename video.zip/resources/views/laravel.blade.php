@extends('default')
@section("mywebpage")
    <div class="container mt-5">
        <h1 class="mt-3">Upload Video</h1>
        <form enctype="multipart/form-data" method="POST">
            @csrf
            <input type="file" name="video" accept="video/*" required id="file">
            <input type="submit" id="submit">
        </form>
    </div>
@stop
