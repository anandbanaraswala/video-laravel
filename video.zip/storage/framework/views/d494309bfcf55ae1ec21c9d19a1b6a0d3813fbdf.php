<html lang="en">
<head>
  <title>ajax Laravel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    #progress-bar
    {
        background-color: #12CC1A;
        color: #FFFFFF;
        width: 0%;
        -webkit-transition: width .3s;
        -moz-transition: width .3s;
        transition: width .3s;
        border-radius: 5px;
    }

    #targetLayer
    {
        width: 100%;
        text-align: center;
    }
  </style>
</head>
<body>
    <?php echo $__env->yieldContent("mywebpage"); ?>
</body>
</html>
<?php /**PATH D:\it_company\video\resources\views/default.blade.php ENDPATH**/ ?>