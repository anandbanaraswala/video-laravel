<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\videoControllerAjax;
use App\Http\Controllers\laravelController;
use App\Http\Controllers\laravelVimeoAjax;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/laravel-vimeo', function () {
    return view('laravel');
});

Route::get('/laravel-vimeo-ajax', function () {
    return view('laravel-ajax');
});

Route::post('/', [videoControllerAjax::class, 'result']);
Route::post('/laravel-vimeo', [laravelController::class, 'storewithform']);
Route::post('/laravel-vimeo-ajax', [laravelVimeoAjax::class, 'storewithajax']);
//Route::get('/curl', [videoControllerAjax::class, 'phpCurl']);
//Route::post('/curl', [videoControllerAjax::class, 'phpCurl']);
Route::match(['get','post'],'/curl',[videoControllerAjax::class, 'phpCurl']); // for both request get and post






