<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use HTTP_Request2;
use App\Models\videoInfo;

class videoControllerAjax extends Controller
{
    public function result(Request $request)
    {
        if($request->file('file'))
        {
            $videofile = $request->file('file');
            $filename = time().'_'.$videofile->getClientOriginalName();
            $location = $videofile->getPathName(); // this is my file
            $filesize = filesize($location);
            $open_file = fopen($location,"rb"); // 'rb' means read in binary.
            $newfile = fopen($filename,"w");
            $start_from = 0;
            while($start_from < $filesize)
            {
                $binary = fread($open_file,10000);
                fwrite($newfile,$binary);
                $start_from += strlen($binary);
                fseek($open_file,$start_from);
            }
            $videofile->move(public_path('files'), $filename);
            return response()->json(['message' => "done"], 200);
            fclose($open_file);
            fclose($newfile);
            unlink($location);
        }
    }

    function phpCurl(Request $request)
    {

        $request = new HTTP_Request2();
        $request->setUrl('https://api.vimeo.com/me/videos');
        $request->setMethod(HTTP_Request2::METHOD_GET);
        $request->setConfig(array(
            'follow_redirects' => TRUE
        ));
        $request->setHeader(array(
            'Authorization' => 'bearer 0b6a6cf854dc39e652a38086636e1bbe',
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept' => 'application/vnd.vimeo.*+json;version=3.0',
            'Cookie' => '__cf_bm=2YC4U81o9bJntVI4Jt2syhvtohH8y3.xGNZnsNmPAjs-1666955633-0-AdOHYAvegyJ/rtuPvP/0gfRVZuKL0gkWfJoScDsZwsKNFkZhGUa4omnurPNX3ycJdPajbG0TGhOVWKRC6HXbICY='
        ));
        $request->addPostParameter(array(
            'upload.approach' => 'tus',
            'size' => '1000'
        ));
        try
        {
            $response = $request->send();
            if($response->getStatus() == 200)
            {
                $response = json_decode($response->getBody(),true);
                $uri =  $response['data'][0]['uri'];
                $name = $response['data'][0]['name'];
                $type = $response['data'][0]['type'];
                $link = $response['data'][0]['link'];
                $played_embed_url = $response['data'][0]['player_embed_url'];
                $duration = $response['data'][0]['duration'];
                $iframe = $response['data'][0]['embed']['html'];
                $thumbnails = $response['data'][0]['pictures'][0]['link'];
                $videoInfoModel = new videoInfo();
                $videoInfoModel->uri = $uri;
                $videoInfoModel->name = $name;
                $videoInfoModel->type = $type;
                $videoInfoModel->link = $link;
                $videoInfoModel->played_embed_url = $played_embed_url;
                $videoInfoModel->duration = $duration;
                $videoInfoModel->iframe = $iframe;
                $videoInfoModel->thumbnails = $thumbnails;
                $videoInfoModel->save();
                return response(array("message"=>"Success !"),200)->header("Content-Type","application/json");
            }
            else
            {
                echo 'Unexpected HTTP status: ' . $response->getStatus() . ' ' .
                $response->getReasonPhrase();
            }
        }
        catch(HTTP_Request2_Exception $e)
        {
            echo 'Error: ' . $e->getMessage();
        }
    }
}
