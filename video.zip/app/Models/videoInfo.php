<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class videoInfo extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $table = 'video';
    protected $fillable = [
        'uri',
        'name',
        'type',
        'link',
        'played_embed_url',
        'duration',
        'iframe',
        'thumbnails'
    ];
}
