@extends('default')
@section("mywebpage")
<div class="container mt-5">
    <h1 class="mt-3">Upload Video</h1>
    <form enctype="multipart/form-data">
        @csrf
        <input type="file" accept="video/*" required id="file">
        <h2 id="message"></h2>
        <input type="submit" id="submit">
    </form>
</div>

<script>
    $(document).ready(function(){
        $("form").on('submit',(e)=>{
            e.preventDefault();
            var files = $('#file')[0].files;
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            var fd = new FormData();
            fd.append('file',files[0]);

            $.ajax({
                url : "/",
                method: 'POST',
                data: fd,
                contentType: false,
                processData: false,
                dataType: 'json',
                beforeSend : function()
                {
                    $("#message").html("Uploading...");
                },
                success : function(response)
                {
                    console.log(response);
                    $("#message").html("");
                },
                error : function(error)
                {
                    console.log(error);
                }
            });
        });
    });
</script>
@stop
