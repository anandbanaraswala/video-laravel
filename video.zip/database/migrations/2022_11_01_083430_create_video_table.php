<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVideoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('video', function(Blueprint $table) {
            $table->id();
            $table->string('uri')->nullable();
            $table->string('name')->nullable();
            $table->string('type')->nullable();
            $table->string('link')->nullable();
            $table->string('played_embed_url')->nullable();
            $table->string('duration')->nullable();
            $table->mediumText('iframe')->nullable();
            $table->mediumText('thumbnails')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('video');
    }
}
