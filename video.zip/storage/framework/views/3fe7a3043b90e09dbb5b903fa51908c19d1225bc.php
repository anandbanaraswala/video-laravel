<?php $__env->startSection("mywebpage"); ?>
    <div class="container mt-5">
        <h1 class="mt-3">Upload Video</h1>
        <form enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="video" accept="video/*" required id="file">
            <input type="submit" id="submit">
        </form>
        <div class="progress w-50 my-2 upload-progress-con d-none" style="height:5px;">
            <div class="progress-bar progress-bar-animated progress-bar-striped progress-control"></div>
        </div>
        <div class="mb-2 progress-details d-none">
            <span class="progress-percentage"></span>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $("form").submit(function(e){
            e.preventDefault();
            $('#loader-icon').show();
            var files = $('#file')[0].files;
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN' : '<?php echo e(csrf_token()); ?>'
                }
            });

            var fd = new FormData();
            fd.append('file',files[0]);

            $.ajax({
                    url : "/laravel-vimeo-ajax",
                    method: 'POST',
                    data: fd,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    xhr : function()
				    {
                        var request = new XMLHttpRequest();
                        request.upload.onprogress= function(e)
                        {
                            var loaded = (e.loaded/1024/1024).toFixed(2);
                            var total = (e.total/1024/1024).toFixed(2);
                            var percentage = (loaded*100)/total;
                            $(".progress-control").css({
                                width : percentage+"%",
                            });
                            $(".progress-percentage").html(percentage.toFixed(2)+"% "+" "+loaded+"MB / "+total+"MB");
                        }
                        return request;
				    },

                    beforeSend : function()
                    {
                        $(".upload-progress-con").removeClass("d-none");
					    $(".progress-details").removeClass("d-none");
                    },
                    success : function(response)
                    {
                        console.log(response);
                        $(".upload-progress-con").addClass("d-none");
						$(".progress-details").addClass("d-none");
                    },
                    error : function(error)
                    {
                        console.log(error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\it_company\video\resources\views/laravel-ajax.blade.php ENDPATH**/ ?>